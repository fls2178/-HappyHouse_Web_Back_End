package com.ssafy.happyhouse.model.dao;

import java.sql.SQLException;

import com.ssafy.happyhouse.model.MemberDto;

public interface LoginDao {
	public MemberDto login(String userid, String userpwd) throws SQLException;

	public void join(String userid, String username, String userpwd, String email);

	public void modify(String org_userid, String org_userpwd, String username, String address, String email, String password);
}
