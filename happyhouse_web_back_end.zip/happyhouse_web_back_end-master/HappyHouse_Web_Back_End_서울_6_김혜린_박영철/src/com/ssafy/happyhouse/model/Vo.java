package com.ssafy.happyhouse.model;

public class Vo {
	String sido;
	String gugun;
	String dong;
	
	public Vo() {
	}

	public Vo(String sido, String gugun, String dong) {
		this.sido = sido;
		this.gugun = gugun;
		this.dong = dong;
	}

	public String getSido() {
		return sido;
	}

	public void setSido(String sido) {
		this.sido = sido;
	}

	public String getGugun() {
		return gugun;
	}

	public void setGugun(String gugun) {
		this.gugun = gugun;
	}

	public String getDong() {
		return dong;
	}

	public void setDong(String dong) {
		this.dong = dong;
	}
	
	
}
