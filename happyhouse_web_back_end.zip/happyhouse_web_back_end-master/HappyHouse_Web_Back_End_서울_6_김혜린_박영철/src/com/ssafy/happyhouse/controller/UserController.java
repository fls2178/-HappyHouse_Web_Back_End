package com.ssafy.happyhouse.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.MemberDto;
import com.ssafy.happyhouse.model.SidoGugunCodeDto;
import com.ssafy.happyhouse.model.service.LoginService;
import com.ssafy.happyhouse.model.service.LoginServiceImpl;
import com.ssafy.happyhouse.model.service.MainServiceImpl;

@WebServlet("/user")
public class UserController extends HttpServlet {
	
	private LoginService loginService;
	
	@Override
	public void init() throws ServletException {
		super.init();
		loginService = new LoginServiceImpl();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}
	
	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String root = request.getContextPath();
		String act = request.getParameter("act");

		if("login".equals(act)) {
			login(request, response);
		} else if("logout".equals(act)) {
			logout(request, response);
		} else if("join".equals(act)) {
			join(request, response);
		} else if("modify".equals(act)) {
			modify(request, response);
		}
	}
	
	
	private void modify(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String org_userid = request.getParameter("userid");
		String org_userpwd = request.getParameter("userpwd");
		String username = request.getParameter("username");
		String address = request.getParameter("address");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		loginService.modify(org_userid, org_userpwd, username, address, email, password);
		System.out.println("modify 중");
		request.getRequestDispatcher(path).forward(request, response);
	}
	//조금있다 수정하기
	private void logout(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		session.removeAttribute("");
		session.setAttribute("id", null);
		try {
			response.sendRedirect("../index.jsp");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String id = request.getParameter("uid");
		String pw = request.getParameter("upw");
		//System.out.println("id:" + id + "/pw:" + pw);
		try {
			MemberDto memberDto = loginService.login(id, pw);
			System.out.println("id:" + memberDto.getUserid());
			if(memberDto != null) {
				HttpSession session = request.getSession();
				session.setAttribute("userinfo", memberDto);
				
				String idsave = request.getParameter("idsave");
				if("saveok".equals(idsave)) {
					Cookie cookie = new Cookie("ssafy_id", id);
					cookie.setPath(request.getContextPath());
					cookie.setMaxAge(60 * 60 * 24 * 365 * 40);
					response.addCookie(cookie);
				} else {
					Cookie cookies[] = request.getCookies();
					if(cookies != null) {
						for(Cookie cookie : cookies) {
							if("ssafy_id".equals(cookie.getName())) {
								cookie.setMaxAge(0);
								response.addCookie(cookie);
								break;
							}
						}
					}
				}
			} else
				request.setAttribute("msg", "아이디 또는 비밀번호 확인 후 로그인해 주세요.");
		} catch(Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "로그인 중 문제가 발생했습니다.");
		}
		request.getRequestDispatcher(path).forward(request, response);
	}
	//회원가입
	public void join(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String userid = request.getParameter("userid");
		String username = request.getParameter("username");
		String userpwd = request.getParameter("password");
		String email = request.getParameter("email");
		
		loginService.join(userid, username, userpwd, email);
		//System.out.println("join중");
		request.getRequestDispatcher(path).forward(request, response);
	}
}
